#ifdef __GNUC__
int main(){return 0;}
#else
int main(){return 1;}
#endif
